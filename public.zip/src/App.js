import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./components/Login";
import AllCompanies from "./components/AllCompanies";
import CreateCompany from "./components/CreateCompany";
import AllEquipments from "./components/AllEquipments";
import CreateEquipments from "./components/AllEquipments";
function App() {
  
  return (
    <Router>
      <Routes>
        <Route index path="/" element={<Login />} />
        <Route index path="/companies" element={<AllCompanies />} />
        <Route index path="/createCompany" element={<CreateCompany />} />
        <Route index path="/equipments" element={<AllEquipments />} />
        <Route index path="/equipments" element={<CreateEquipment />} />
      </Routes>
   
    </Router>
  );
}

export default App;