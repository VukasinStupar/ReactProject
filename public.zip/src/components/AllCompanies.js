import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/allCompanies.css"

const AllCompanies = () => {
    const [companies, setCompanies] = useState([]);
    
  

    useEffect(() => {
 
        fetchCompanies();
    }, []);
    
    const fetchCompanies = async () => {
        try {
          const response = await fetch("http://localhost:8080/api/companies", {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json"
            },
          });
          const data = await response.json();
          setCompanies(data);
        } catch (error) {
          console.log("Error fetching comapnies:", error);
        }
    };
      


    return (
        <div className="container">
        <div className="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Description</th>
                        <th>Average Grade</th>
                    </tr>
                </thead>
                <tbody>
                    {companies.map((company) => (
                        <tr key={company.id}>
                            <td>{company.name}</td>
                            <td>{company.adress}</td>
                            <td>{company.description}</td>
                            <td>{company.averageGrade}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
    );
}

export default AllCompanies;