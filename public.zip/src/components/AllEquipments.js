import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/allEquipments.css"

const AllEquipments = () => {
    const [equipments, setEquipments] = useState([]);
    
  

    useEffect(() => {
 
        fetchEquipments();
    }, []);
    
    const fetchEquipments = async () => {
        try {
          const response = await fetch("http://localhost:8080/api/equipments", {
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json"
            },
          });
          const data = await response.json();
          setEquipments(data);
        } catch (error) {
          console.log("Error fetching equipments:", error);
        }
    };
      


    return (
        <div className="container">
        <div className="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>companyId</th>
                    </tr>
                </thead>
                <tbody>
                    {equipments.map((equipment) => (
                        <tr key={equipment.id}>
                            <td>{equipment.name}</td>
                            <td>{equipment.description}</td>
                            <td>{equipment.companyId}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
    );
}

export default AllEquipments;